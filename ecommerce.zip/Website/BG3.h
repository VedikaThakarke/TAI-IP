
<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>BG3</title>
	<style>
		table ,th,tr{
            align-items: center;
            text-align: center;
            padding: 10px;
        }
        #photo-frame{
        margin: 50px;
        border: 5px solid black;
        padding: 5px;
    }
        </style>
</head>
<body>
	<div id="Baby wear" style="background-color: lightslategray;">
    <h1 align="center" style="background-color: dimgrey; color: white;">Girl Wear 3</h1>
    <hr>
    <table width="50%" align="center">
        <thead align="center" style="background-color: floralwhite;">
            <tr>
 	            <td> <img src="C:\Users\nge28\OneDrive\Desktop\YUKTA\BG3.jpg" width="250" height="250">
                <h2> Price: <del>Rs. 1500</h2>
                <h2> Price: Rs. 1400</h2>
                <h2> Color: Pink with red flowers</h2>
                <h2> Size: Small</h2>
                <h2><a href="Cart.html">Add to cart</a></h2>                
			</td>			
</tr>
</thead>
</body>
</html>